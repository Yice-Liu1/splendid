#ifndef __DELAY_H
#define __DELAY_H

void delay_ms(unsigned int t);
void delay_us(unsigned int t);

#endif
