#ifndef __USART6_H
#define __USART6_H

#include <stdio.h>
#include "stm32f4xx.h"



void USART6_INIT(void);
void CopeSerial2Data(unsigned char ucData);



#endif

