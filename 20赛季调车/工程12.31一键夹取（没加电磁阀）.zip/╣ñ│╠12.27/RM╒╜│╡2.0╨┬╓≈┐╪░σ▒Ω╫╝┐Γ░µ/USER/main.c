#include "main.h"

float err[3],chazhi;

float ml; 
float cbw;


int main(void)
{   			
portinit();//�ɿص�Դ��ʼ��
//SetFrictionWheelSpeed(1500);
	BSP_Init();	
	PWM_Config();
	YAW(1200);//С˳
		///PITCH(1500);//����
//	SetFrictionWheelSpeed(0)
	PID_Reset(&GMPPositionPID);
	PID_Reset(&GMYPositionPID);
	//SetFrictionWheelSpeed(800);
	DOOR_Init();
	delay_ms(300);
	EDOOR1_CLOSE();
	EDOOR2_CLOSE();
	EDOOR3_CLOSE();
	EDOOR4_CLOSE();
	EDOOR5_CLOSE();
	
	while(1)	
	{	

	
		//PITCH(1700);
//YAW(2000);//2000
	 remote();
	//	HANDPID(ml);
		//Set_GEThand(CAN2,cbw);
	//	delay_ms(1);
		 //HANDPID(-500);
//		MOTORPID(2000,CM2SpeedPID.ref,CM3SpeedPID.ref,CM4SpeedPID.ref);	
	//	ARMPID(500);
//		cml=TravelSwitch1;
//		if(cml==1)  GREEN_LED_ON();
	}

}

