#ifndef __CAN1_H
#define __CAN1_H

void CAN1_Config(void);
float map(float val, float I_Min, float I_Max, float O_Min, float O_Max);//2006�Ƕ�ӳ��
#endif
