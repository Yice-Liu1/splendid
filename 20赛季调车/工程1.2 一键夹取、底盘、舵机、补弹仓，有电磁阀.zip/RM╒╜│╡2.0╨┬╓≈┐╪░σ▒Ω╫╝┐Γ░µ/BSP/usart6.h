#ifndef __UART8_H
#define __UART8_H

#include <stdio.h>
#include "stm32f4xx.h"



void UART8_INIT(void);
void CopeSerial2Data(unsigned char ucData);



#endif

