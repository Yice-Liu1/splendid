#ifndef __MPU6050_INTERRUPT_H
#define __MPU6050_INTERRUPT_H
#include "main.h"
extern u8 isMPU6050_is_DRY;

void MPU6050_IntConfig(void);

#endif

