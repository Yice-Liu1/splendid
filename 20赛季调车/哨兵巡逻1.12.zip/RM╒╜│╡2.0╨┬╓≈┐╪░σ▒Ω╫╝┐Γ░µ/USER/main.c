//����1��pitch�Ƕ�287.7-249,yaw��176-70
 
#include "main.h"
static float distance=0;
static float distance1=0;
float YAW;
float BAIDONG_YAW;
int BAIDONG_YAW_flag;
float stastic_yaw_angle;
long int i;  //��ʱ
float TEMP[6];
int cxgkey;
float err[3],chazhi;
float manifold_y;
float	manifold_x;

float XC=175.0;
float YC=80.0;
float SSH=0.1;
float sh=125;

float ZBsave=2;
int ssh=30;
float xsh=1.5;
float dpz=0.1;
float aq=20;

int iii=3;
//int c[600]={0};
u8 exam=1;


//2020 �²���

//pitch 305-330
//yaw   

float pitch_wish=320;
float yaw_wish=120;     //����120������ͷ���ģ���˳ʱ��155
float yawcounter=0;
float yawadder=120;
unsigned short x_coordinate_last;
unsigned short x_coordinate_use;

float kx=5000;
float ky=350000;
float kx2=5000;
u16 flag1=0;
int iii_i;
int main(void)

{   		
	u16 t=0;
	u16 f2=0;
	u16 w1=0,w2=0;

	float manifold_x_old=0;   //   172  233  232-172    120
	//float dpz=0;
	int common_i=0;
	BSP_Init();	
	TIM4_Config();
	LASER();  


	PID_Reset(&GMPPositionPID);
	PID_Reset(&GMYPositionPID);
	SetFrictionWheelSpeed(800);
	delay_ms(300);

	MPU6050_Init();
	IST8310_Init();
	Init_Quaternion();
	 USART1_Config();
 Led_Config();

 TIM6_Start();   
	TIM3_Int_Init(10000,80);
	//TIM5_Int_Init(10000,80);
 
	while(1)	
	{
distance1=soner_getdistance1();
	distance=soner_getdistance();
		
		
/*******double********/
		if(flag1==0||flag1==2)//���distance�ұ�distance1
			
MOTORPID(1000,-1000,0,0);
		if(distance1<300&&distance>200)
		{delay_ms(10);
			if(distance1<300&&distance>200)
			flag1=1;}
		if(distance1>300&&distance<200)
			{delay_ms(10);
			if(distance1>300&&distance<200)			
			flag1=2;}
		if(flag1==1)
			MOTORPID(-1000,1000,0,0);


	}	

	}