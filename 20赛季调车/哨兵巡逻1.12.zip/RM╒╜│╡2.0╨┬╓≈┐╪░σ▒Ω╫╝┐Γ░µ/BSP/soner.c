#include "main.h"
#include "stm32f4xx_exti.h"
//#include "stm32flxx_it.h"
	uint16_t time_nodel,time_node2;
	uint16_t time_node3,time_node4;
static float distance_temp=0,distance_temp1=0;
static float distance_last=0;
static float distance_result;
signed int measure,measure1;
int i_i;
void Delay_us(uint16_t time)
{
		uint16_t al=TIM3->CNT;
	while(TIM3->CNT-al<time);

}
void soner_startrange1(void)
{
		
		GPIO_SetBits(SONER_PORT1,SONER_TRIG_PIN1);
	delay_ms(1);
	GPIO_ResetBits(SONER_PORT1,SONER_TRIG_PIN1);
}
uint16_t soner_gettime1(void)
{
uint32_t a;
	a=TIM5->CNT;
	return a;

}


float soner_getdistance1(void)
{
	soner_startrange1();

	while(GPIO_ReadInputDataBit(SONER_PORT1,SONER_ECHO_PIN1)==0);
		time_node3=soner_gettime1();
	while(GPIO_ReadInputDataBit(SONER_PORT1,SONER_ECHO_PIN1)==1);
		time_node4=soner_gettime1();
	if(time_node3<=time_node4)
	{measure1=time_node3-time_node4;
	distance_temp1=measure1*17.0/100;}
	/*******�޷��˲�*******/
//	if(distance_last==0)
//		distance_last=distance_temp;
//	if(distance_last-distance_temp>100||distance_temp-distance_last>100)
//	{
//			distance_result=distance_last;
//		distance_last=distance_temp;
//	
//	
//	}
//	else
//	{
//		distance_result=distance_temp;
//		distance_last=distance_temp;
//	
//	}
return -distance_temp1;


}






void soner_startrange(void)
{
		
		GPIO_SetBits(SONER_PORT,SONER_TRIG_PIN);
	delay_ms(1);
	GPIO_ResetBits(SONER_PORT,SONER_TRIG_PIN);
}
uint16_t soner_gettime(void)
{
uint32_t a;
	a=TIM3->CNT;
	return a;

}




float soner_getdistance(void)
{
	
	soner_startrange();

	while(GPIO_ReadInputDataBit(SONER_PORT,SONER_ECHO_PIN)==0);
	{
		i_i++;
		time_nodel=soner_gettime();
	}
	while(GPIO_ReadInputDataBit(SONER_PORT,SONER_ECHO_PIN)==1);
		time_node2=soner_gettime();
	if(time_nodel<=time_node2)
	{measure=time_node2-time_nodel;
	distance_temp=measure*17.0/100;}
	/*******�޷��˲�*******/

return distance_temp;


}
