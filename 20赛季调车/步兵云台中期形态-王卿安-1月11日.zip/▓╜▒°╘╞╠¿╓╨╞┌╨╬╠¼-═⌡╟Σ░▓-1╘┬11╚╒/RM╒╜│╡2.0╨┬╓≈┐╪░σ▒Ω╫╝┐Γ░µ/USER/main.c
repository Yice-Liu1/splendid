//����1��pitch�Ƕ�287.7-249,yaw��176-70
 
#include "main.h"

float YAW;
float BAIDONG_YAW;
int BAIDONG_YAW_flag;
float stastic_yaw_angle;
long int i;  //��ʱ
float TEMP[6];
int cxgkey;
float err[3],chazhi;
float manifold_y;
float	manifold_x;

float XC=175.0;
float YC=80.0;
float SSH=0.1;
float sh=125;

float ZBsave=2;
int ssh=30;
float xsh=1.5;
float dpz=0.1;
float aq=20;

int iii=3;
//int c[600]={0};
u8 exam=1;


//2020 �²���

//pitch 305-330
//yaw   

float pitch_wish=125;
float yaw_wish=300;     //����120������ͷ���ģ���˳ʱ��155
float yawcounter=0;
float yawadder=120;
unsigned short x_coordinate_last;
unsigned short x_coordinate_use;
float x_half;
float manifold_x_old=0,manifold_x_use=0;//��������ж�
float compare=0,compare2=0,correct=0,flag2=0;//��ֹ������׼�����ж�
float boundge1=305,boundge2=335,boundge3=165,boundge4=195;

float kx=10;
float ky=400000;
float kx2=3000;
float kx3=80000000;
float gai=0;
int main(void)

{   ;		

	//float manifold_x_old=0;   //   172  233  232-172    120
	//float dpz=0;
	int common_i=0;
	BSP_Init();	
	TIM4_Config();
	LASER();  


	PID_Reset(&GMPPositionPID);
	PID_Reset(&GMYPositionPID);
	SetFrictionWheelSpeed(800);
	delay_ms(300);

	MPU6050_Init();
	IST8310_Init();
	Init_Quaternion();
			POWER1_CTRL();     //�ɿص�Դ����wjn
			POWER2_CTRL();
			POWER3_CTRL();
			POWER4_CTRL();

		
 TIM6_Start();   
 
	while(1)	//xiaolaji&&benji&&shaji&&
	{
		IMU_getYawPitchRoll(angle) ;
		GetPitchYawGxGyGz();
		manifold_y=(float)y_coordinate-180;
		manifold_x=(float)x_coordinate-320;
		x_half=manifold_x/320;
//		if(manifold_x<-25&&manifold_x>-45)
//		{
//			x_coordinate=320;
//			manifold_x=0;
//			yaw_wish=yaw_wish-5;
//		}
//		if(manifold_x<25&&manifold_x>45)
//		{
//			x_coordinate=320;
//			manifold_x=0;
//			yaw_wish=yaw_wish+5;
//		}
		
		x_coordinate_use=x_coordinate;
//		if( (x_coordinate_last-x_coordinate_use)==0 )
//			gai++;
//		if(gai=10)
//		{
//			x_coordinate=320;
//			manifold_x=0
//			yaw_wish=yaw_wish;
//			gai=0;
//		}

		if(x_coordinate<boundge1||x_coordinate>boundge2)    //300-340
		{
			if( (x_coordinate_last-x_coordinate_use)!=0 )
			{
				yaw_wish=yaw_wish+x_half*kx;
			//	gai=0;
			}
			
		}
		if(y_coordinate<boundge3||y_coordinate>=boundge4)
		{
			pitch_wish=pitch_wish-manifold_y/kx2;
		}
		x_coordinate_last=x_coordinate_use;

		if(pitch_wish>133) pitch_wish=133;
		if(pitch_wish<110) pitch_wish=110;
		if(yaw_wish>330) yaw_wish=330;
		if(yaw_wish<270) yaw_wish=270;

		Gimbal_Set(pitch_wish,yaw_wish,MPU6050_Real_Data.Gyro_Y,MPU6050_Real_Data.Gyro_Z,REAL_YP,REAL_YY);
		
	}
}